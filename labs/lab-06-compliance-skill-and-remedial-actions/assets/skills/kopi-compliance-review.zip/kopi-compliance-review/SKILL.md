---
name: kopi-compliance-review
description: Reviews a Kopi & Coins episode against studio and industry standards; reports findings with evidence, risk and a remedial action. Use before any approval or upload.
---

# Kopi & Coins compliance review

## When to use
Before an episode goes to human approval, and before any upload plan is
final.

## Procedure
1. Read `references/standards.md`.
2. Read the evidence the user gives: QC report, captions.srt, the approved
   script, music licence notes, the upload plan and any production notes.
3. Check each area: platform specification, loudness and true peak,
   captions and safe area, rights (music, images), personal data, money
   messaging (general education only, no products, no guarantees,
   disclaimer present), AI-content label, and the studio's brand rules.
4. Return a table with one row per finding:
   | # | Finding | Standard | Evidence | Risk (high/medium/low) | Remedial action | Owner |
5. Order findings by risk. Mark anything you could not verify as UNVERIFIED.
6. Finish with a one-line verdict: READY FOR HUMAN APPROVAL, or NOT READY.

## Pitfalls
- Never edit or regenerate the video. Report only.
- Never approve. Only a person approves.
- Never print or store keys or personal data in the report.

## Verification
Every finding has a standard, evidence, a risk level, an action and an owner.
