# Standards reference for kopi-compliance-review

## Technical
- Format: 1080x1920, 9:16, constant 24/25/30 fps, H.264 MP4, 55-60 s
  (TikTok, Shorts, Reels); 1920x1080 for YouTube 16:9.
- Resolution: the final cut uses 1080p upgrades only — no low-res drafts.
- Loudness: about -14 LUFS integrated for social platforms; true peak no
  higher than -1 dBTP. Broadcast reference: EBU R128 -23 LUFS.
- Captions: every spoken line; 100% accurate; at most two lines; above the
  bottom 20% of the frame (35% for Instagram Reels) and clear of the
  right-edge buttons (WCAG 2.2 1.2.2; platform safe areas).

## Content and legal (Singapore) — general guidance, not legal advice
- Copyright Act 2021: every music track, image and clip licensed or
  rights-cleared; licence recorded in the licence log.
- PDPA: no personal data — no real names, NRIC-like numbers, phone numbers,
  addresses or account screens, including inside generated shots.
- Financial Advisers Act (MAS): recommending specific investment or insurance
  products is regulated advice. Kopi & Coins stays general; no product names.
- Singapore Code of Advertising Practice (ASAS): legal, decent, honest and
  truthful; no guaranteed or exaggerated outcomes; sponsorship disclosed.
- AI labels: TikTok — More options > AI-generated content; YouTube — Studio >
  Attributes > AI use. Kopi & Coins labels every episode. Keep C2PA content
  credentials where tools add them.

## Studio rules
- End card shows the call to action and "For general education only. Not financial advice." for at least 3 s.
- Fictional people only; brand colours kopi brown, cream and teal.

## Risk levels
- HIGH: legal, regulatory or reputational exposure (rights, personal data,
  misleading money claims, missing AI label, missing disclaimer).
- MEDIUM: viewer experience or platform rejection (loudness, captions,
  format, safe area).
- LOW: polish (minor timing, colour match).
