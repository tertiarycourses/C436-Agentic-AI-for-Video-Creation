---
name: video-script
description: Writes the production script from an approved storyboard: scenes, shots, VO, asset bible, text- and image-to-video prompts per shot, timing check. Shown as an artifact for approval.
---

# Video script: the production bible

The storyboard says **what** we see. The script says **exactly** what Higgsfield must make, what each character says, and how long every piece runs. After approval, the `higgsfield-video` skill executes it line by line, without guessing.

## Preconditions
- The storyboard is **APPROVED**. Check project knowledge for `02-storyboard__…-approved.html`, or an approval earlier in this chat.
- If it isn't approved, stop and say: "The storyboard is still a draft. Approve it first, or tell me what to change." Never script from a draft.

## What you produce (four parts, in one artifact)

### Part A: Header and timing
- Title, platform, aspect, fps (default 30), target length.
- A sum of shot durations. It must equal the target ±0.5 s.
- Spoken word count. At most 2.5 words per second of VO time; flag lines that won't fit.

### Part B: Asset bible (generate these first in Higgsfield)
One entry per character (`@`), location (`#`) and prop (`@`):

| Field | Rule |
|---|---|
| `handle` | `@Rachel`, `#HDB-bedroom-night`, `@BlueTin` |
| `kind` | character, location or prop |
| `look` | The full visual description from the character bible, word for word. Reuse it verbatim in every prompt. |
| `never_changes` | 2-4 continuity anchors (glasses, mustard cardigan, jade bangle on the left wrist). |
| `reference_prompt` | A still-image prompt for the reference: front view, neutral soft light, plain cream background, photoreal, 9:16. Add a three-quarter view for characters. |
| `consistency_method` | `element` (Higgsfield reference Element), `soul_id` (trained Soul Character, 5-20 photos), or `start_frame` (approved still reused as the first frame). |

Fictional people only. Never describe a real, identifiable person.

### Part C: Scenes and shots (the shooting script)
For every shot from the storyboard, keep the same `id` and add:

| Field | Rule |
|---|---|
| `duration` | Seconds on the timeline after trimming. |
| `gen_seconds` | What you ask the model for. It must be ≥ duration and a length the model supports (check `models_explore`). |
| `model` | Suggested model, e.g. `kling3_0` for dialogue-free character shots, `seedance_2_5` for multi-shot or image-to-video. The live `models_explore` list wins. |
| `camera_move` / `effect` | From the storyboard. A Higgsfield Camera Controls name. |
| `vo` / `dialogue` | Final words, with the speaker. Note lip-sync needs: generate speech in the clip, or record VO separately and avoid visible mouths. |
| `t2v_prompt` | Text-to-video: the full formula, all look details written out. |
| `i2v_prompt` | Image-to-video: **motion only**. The start frame already holds the look. E.g. "She lifts the lid slowly; camera: Tilt Down; soft window light flickers." |
| `start_frame` | Which reference still or earlier shot to use (`@AhMa-ref-front`, `S03-SH01 last frame`). |
| `caption` | The burned-in caption for this shot (spoken line or on-screen text). |
| `transition_in` | cut, crossfade, slide, zoom, wipe or dip. |

Prompt formula (see `references/prompt-formula.md`):
`[shot size] [angle] of [subject + @look], [action verb + detail], in [location, time], [lighting], [mood], [colour grade], camera: [Higgsfield move], [lens], [aspect], [negative: no on-screen text, no logos]`

### Part D: Audio and captions
- Music: mood, BPM range, where it enters and resolves, and its licence source. Kopi & Coins rule 4: licensed or rights-cleared only.
- VO plan: who records it and where (Higgsfield voiceover tools or a human).
- Caption list with `start`, `end` and `text`, built from the shot timings. It feeds the `.srt` and `lahlah-edit.json` later.

## Render and approve
1. Fill `templates/script-template.html`. Replace only the JSON in `<script id="script-data">`.
2. Publish it as one self-contained HTML artifact titled `Script: [TITLE] v[N] (DRAFT)`.
3. Send this and **stop**:

> **Script v[N] is a DRAFT.** Total [X] s of [TARGET] s, [W] spoken words, [K] assets to generate first.
> Reply **APPROVE** to lock it for Higgsfield, or tell me what to change.

4. Only an explicit approval counts. On approval:
   - Set `status` to `APPROVED` and add `approved_at`.
   - Re-render the artifact.
   - Ask the user to save it to project knowledge as `03-script__script-v[N]-approved.html`.

## Quality bar
- Every `@`/`#` handle used in a shot exists in the asset bible.
- Every i2v prompt describes motion, not the look again. Every t2v prompt carries the full look.
- No two adjacent shots both use a hard Crash Zoom or Whip Pan; save the big moves for the beats that matter.
- Text the model must render is kept to deliberate props only. Captions and end cards are editor jobs.
- Kopi & Coins: no product names, no percentages, no returns, disclaimer on the end card. Phone and bank screens face away or are blurred.
