# Scene-creation prompt formula

```
[SHOT SIZE] [ANGLE] of [SUBJECT + @look], [ACTION verb + detail],
in [LOCATION, time of day], [LIGHTING], [MOOD], [COLOUR GRADE],
camera: [HIGGSFIELD MOVE], [LENS], [ASPECT], [NEGATIVES]
```

| Slot | Good | Weak |
|---|---|---|
| Shot size | `MCU` | "a shot of" |
| Subject + look | `@Rachel: 29, round tortoiseshell glasses, mustard-yellow cardigan` | "a woman" |
| Action | `lifts the tin lid slowly, then freezes` | "is there" |
| Location | `HDB kitchen, 7 pm, rain on the window` | "a room" |
| Lighting | `single warm desk lamp, deep shadows` | "nice lighting" |
| Mood | `tense, quiet` | "emotional" |
| Grade | `teal-and-kopi-brown, low saturation` | "cinematic" |
| Camera | `Dolly In`, `Crash Zoom In`, `Arc Right` | "camera moves" |
| Lens | `85mm, shallow depth of field` | — |
| Negatives | `no on-screen text, no logos, phone screen blurred` | — |

## Text-to-video vs image-to-video
- **T2V** builds the whole look from words. Write every look detail out.
- **I2V** starts from an approved still, so the look is already there. Describe **motion only**: subject motion, camera move, light change. Repeating the look can fight the start frame.

**I2V example:**
> Ah Ma lifts the lid; three envelopes come into view; steam from her kopi drifts across frame. Camera: Tilt Down. Light from the window brightens slightly.

## Order of work in Higgsfield
1. Reference stills for every character, location and prop. Approve them.
2. Hero shots, the ones that carry the hook and the payoff.
3. Everything else.
4. Re-roll only what fails the check.
