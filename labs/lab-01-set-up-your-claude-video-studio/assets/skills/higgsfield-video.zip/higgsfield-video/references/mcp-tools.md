# Higgsfield MCP tool map (checked 8 Nov 2026)

**Source:** Scalekit's catalog of the hosted server `https://mcp.higgsfield.ai/mcp` (https://www.scalekit.com/connectors/higgsfieldmcp). Scalekit prefixes names with `higgsfieldmcp_`; inside Claude the names appear without it.

**Rule:** trust your live tool list over this file. If a name here is missing, do the step by hand on higgsfield.ai and say so.

| Step in this skill | Tool | Confidence |
|---|---|---|
| Check credits and plan | `balance` | Listed |
| Credit history | `transactions` | Named in `balance` description |
| Pick and validate models | `models_explore` (`recommend`, `get`) | Listed |
| Camera presets for image-to-video | `presets_show` | Listed |
| Reference stills | `generate_image` (count 2-4 = variants), `generate_image_batch` (2-12 different prompts) | Listed / named |
| Cost preflight | `get_cost: true` on generation tools | In `generate_image` description |
| One clip | `generate_video` | Listed |
| Many clips | `generate_video_batch` (1-12) | Listed |
| Poll many | `jobs_wait` (1-12 jobs, ≤ 15 s per call, `all_terminal`, `poll_after_seconds`) | Listed |
| Poll one | `job_status` | Named |
| Show a finished set | `show_generation_by_ids` (≤ 60 jobs) | Named |
| Browse history | `show_generations` | Listed |
| User uploads a local file | `media_upload_widget` | Named |
| Import from a web URL | `media_import_url` | Named |
| Agent uploads bytes | `media_upload` → `media_confirm` | Listed / named |
| List uploads | `show_medias` | Listed |
| Soul characters | `show_characters` (`action='train'` only on request, 5-20 photos) | Named |
| Rights check | `reveal_generation` (for `ip_detected`, Seedance family) | Listed |
| Voices | `list_voices`, `create_voice`, `voice_change`, `generate_audio` | Listed / named |
| Workspaces | `list_workspaces`, `select_workspace` (persists; changes billing) | Listed / named |
| Cut-outs, upscale | `remove_background`, `upscale_image` | Listed |
| TikTok | `tiktok_accounts`, `tiktok_publish` (posts publicly) | Listed / named |
| Folders / projects in Assets | **None found.** Ask the user to create the folder and use **Move to** | Awaiting verification |

"Listed" = name and description on the catalog page. "Named" = referenced by another tool's description; the schema has not been read.
