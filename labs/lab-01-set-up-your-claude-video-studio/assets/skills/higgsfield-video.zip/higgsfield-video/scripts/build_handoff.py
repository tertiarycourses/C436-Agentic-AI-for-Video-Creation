#!/usr/bin/env python3
"""Build lahlah-edit.json and captions.srt from a production.json.

Usage: python3 build_handoff.py production.json [--out DIR] [--target SECONDS]

production.json has the same fields as lahlah-edit/1 (schema may be omitted).
Standard library only. Exits 1 and prints every problem if validation fails.
"""
import argparse, json, os, re, sys

PLATFORMS = {"tiktok", "youtube", "youtube-shorts", "reels", "microdrama"}
TRANSITIONS = {"cut", "crossfade", "slide", "zoom", "wipe", "dip"}
AUDIO_TYPES = {"music", "vo", "sfx"}
ORDER = ["schema", "title", "platform", "aspect", "fps", "higgsfield_project", "clips", "audio", "captions"]
CLIP_ORDER = ["id", "scene", "shot", "src", "duration", "trim_in", "trim_out", "transition_in", "caption", "voiceover"]


def num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def validate(d, target=None):
    errs = []
    if d.get("schema", "lahlah-edit/1") != "lahlah-edit/1":
        errs.append("schema must be 'lahlah-edit/1'")
    for k in ORDER[1:]:
        if k not in d:
            errs.append("missing field: " + k)
    if errs:
        return errs, 0.0
    if d["platform"] not in PLATFORMS:
        errs.append("platform must be one of " + ", ".join(sorted(PLATFORMS)))
    if not re.match(r"^\d+:\d+$", str(d["aspect"])):
        errs.append("aspect must look like 9:16")
    if not num(d["fps"]) or d["fps"] <= 0:
        errs.append("fps must be a positive number")
    elif d["fps"] not in (24, 25, 30, 50, 60):
        errs.append("fps must be 24, 25, 30, 50 or 60: use the clips' own "
                    "frame rate (Seedance shots are 24)")
    hp = d["higgsfield_project"]
    if not isinstance(hp, dict) or "name" not in hp or "url" not in hp:
        errs.append("higgsfield_project needs name and url")
    timeline, seen = 0.0, set()
    for i, c in enumerate(d["clips"]):
        tag = "clips[%d] %s" % (i, c.get("id", "?"))
        for k in CLIP_ORDER:
            if k not in c:
                errs.append(tag + ": missing " + k)
        if any(k not in c for k in CLIP_ORDER):
            continue
        if not re.match(r"^S\d{2}-SH\d{2}$", c["id"]):
            errs.append(tag + ": id must look like S01-SH01")
        if c["id"] in seen:
            errs.append(tag + ": duplicate id")
        seen.add(c["id"])
        if not str(c["src"]).startswith("https://"):
            errs.append(tag + ": src must be the https Higgsfield result URL")
        if c["transition_in"] not in TRANSITIONS:
            errs.append(tag + ": transition_in must be one of " + ", ".join(sorted(TRANSITIONS)))
        if not all(num(c[k]) for k in ("duration", "trim_in", "trim_out")):
            errs.append(tag + ": duration, trim_in, trim_out must be numbers")
            continue
        if not (0 <= c["trim_in"] < c["trim_out"] <= c["duration"] + 1e-6):
            errs.append(tag + ": need 0 <= trim_in < trim_out <= duration")
        timeline += c["trim_out"] - c["trim_in"]
    for i, a in enumerate(d["audio"]):
        for k in ("src", "start", "volume", "type"):
            if k not in a:
                errs.append("audio[%d]: missing %s" % (i, k))
        if a.get("type") not in AUDIO_TYPES:
            errs.append("audio[%d]: type must be music, vo or sfx" % i)
        if num(a.get("volume")) and not 0 <= a["volume"] <= 1:
            errs.append("audio[%d]: volume must be 0-1" % i)
    prev_end = 0.0
    for i, cap in enumerate(sorted(d["captions"], key=lambda c: c.get("start", 0))):
        if not (num(cap.get("start")) and num(cap.get("end")) and cap["end"] > cap["start"]):
            errs.append("captions[%d]: end must be after start" % i)
            continue
        if cap["start"] < prev_end - 1e-6:
            errs.append("captions[%d]: overlaps the previous caption" % i)
        if cap["end"] > timeline + 0.05:
            errs.append("captions[%d]: ends after the timeline (%.2f s)" % (i, timeline))
        prev_end = cap["end"]
    if target is not None and abs(timeline - target) > 0.5:
        errs.append("timeline is %.2f s but target is %.2f s" % (timeline, target))
    return errs, timeline


def srt_time(t):
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return "%02d:%02d:%02d,%03d" % (h, m, s, ms)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("production")
    ap.add_argument("--out", default=".")
    ap.add_argument("--target", type=float, default=None)
    a = ap.parse_args()
    with open(a.production, encoding="utf-8") as f:
        d = json.load(f)
    d["schema"] = "lahlah-edit/1"
    errs, timeline = validate(d, a.target)
    if errs:
        print("NOT WRITTEN. Fix these:\n- " + "\n- ".join(errs))
        sys.exit(1)
    out = {k: d[k] for k in ORDER}
    out["clips"] = [{k: c[k] for k in CLIP_ORDER} for c in d["clips"]]
    out["captions"] = sorted(d["captions"], key=lambda c: c["start"])
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "lahlah-edit.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    with open(os.path.join(a.out, "captions.srt"), "w", encoding="utf-8") as f:
        for i, c in enumerate(out["captions"], 1):
            f.write("%d\n%s --> %s\n%s\n\n" % (i, srt_time(c["start"]), srt_time(c["end"]), c["text"].strip()))
    print("OK: %d clips, %.2f s timeline, %d captions -> lahlah-edit.json, captions.srt" % (len(out["clips"]), timeline, len(out["captions"])))


if __name__ == "__main__":
    main()
