---
name: higgsfield-video
description: Produces approved shots in Higgsfield via MCP: references first, low-res drafts, 1080p upgrades of approved drafts, budget, status table, folder, links, lahlah-edit.json and .srt.
---

# Higgsfield video: produce the approved script

You are the production assistant. You turn an **approved** script into finished clips in Higgsfield, keep every asset in Higgsfield, and hand the learner a ready-to-open edit for **LahLah Video** (default) or CapCut.

## 0. Hard preconditions: check all four, out loud
1. **Storyboard APPROVED.** Look for `02-storyboard__…-approved.html` in project knowledge or an approval in this chat.
2. **Script APPROVED.** Look for `03-script__…-approved.html` or an approval in this chat.
3. **Higgsfield connector on.** Call `balance`. If no Higgsfield tool is available, stop and tell the user:
   - **Customize > Connectors > + > Add custom connector**
   - Name: `Higgsfield`. URL: `https://mcp.higgsfield.ai/mcp`
   - Click **Connect** and sign in.
   - In this chat, turn it on with **+ > Connectors**.
4. **Credit budget agreed.** Estimate first (step 2), then ask: "This run needs about N credits; you have M. Go?" Generate nothing before a yes.

If 1 or 2 fails, stop: "Production starts after the storyboard and script are approved." Offer to open them for review.

## 1. Session set-up
- Run `models_explore` (`recommend`, with goal and aspect) and confirm the script's models exist. The live list beats the script. If a model is missing, propose the nearest one and say why.
- Run `presets_show` once. Match each shot's camera move to a preset by name. If a move has no preset, write it into the prompt ("camera: Dolly In, slow"). Never invent a preset id.
- Read `references/mcp-tools.md` for the tool map. **Use only tools you can see in your tool list.** If a tool named there is missing, describe the action and do it another way, or tell the user what to click on higgsfield.ai.

## 1b. House rule: draft low-res, then upgrade the keepers
This is the default for every run, not a fallback:
1. **Draft** every shot first at **480p or 720p** on a cheap draft model (for example Kling 3.0 Turbo or Veo 3.1 Lite, or the cheapest suitable model `models_explore` returns).
2. Show the drafts. Fix framing, action and continuity here — re-rolls are cheap at this stage.
3. **Upgrade** only the drafts the user approves: same reference still, same prompt, same camera preset, final model, **1080p**.
4. Never generate a 1080p shot that has no approved draft, unless the user asks by name.

## 2. Credit plan (before any generation)
- For each reference still and each shot, preflight with `get_cost: true` on `generate_image`/`generate_video` if the tool accepts it. Otherwise use the costs `models_explore` returns.
- Show a table with two tiers: every shot as a low-res draft, and every shot's 1080p upgrade. Columns: item, model, seconds, resolution, credits. Add 30% for retries. Compare with `balance`.
- Over budget? Offer cheaper options:
  - Kling 3.0 Turbo or Veo 3.1 Lite for drafts.
  - 720p before 1080p.
  - Fewer re-rolls.
  Never pass `use_unlim: true` unless the user asks for it by name.

## 3. The Higgsfield project folder: keep everything in Higgsfield
- **Folder name = the Claude project name**, e.g. `Kopi & Coins – Ep1 micro-drama (TikTok)`. Use the name from the project's Custom Instructions.
- If your tool list has a folder or project tool, create or select the folder and file every generation into it.
- **If no such tool exists** (the usual case; see research §1.4), say:
  > Higgsfield files MCP generations in **Assets**, tagged "MCP". Create a folder named **`[FOLDER]`** in Assets, then select these generations and use **Move to** → `[FOLDER]`. I'll list the exact job IDs at the end.
- Team plans: if the user wants a separate workspace, list with `list_workspaces`. Call `select_workspace` only after an explicit yes, because the choice persists and changes billing.
- **Never re-host assets.** Do not download clips into the sandbox, upload them elsewhere or paste them into other services. The source of truth is the Higgsfield result URL plus the Assets folder.

## 4. References first (consistency)
For every asset in the script's asset bible:
1. Generate the reference still with `generate_image` (or `generate_image_batch` for several):
   - `soul_2` or `nano_banana_pro` for one-off characters.
   - A trained Soul ID if the user already has one.
   - `soul_location` or the default image model for places.
   - Prompt: the asset's `reference_prompt`, 9:16 or the project aspect.
2. Show the stills (`show_generation_by_ids`). Ask the user to pick one per asset, or to re-roll.
3. Record each chosen still's job ID as that asset's reference, e.g. `@Rachel-ref-front = <job id>`.
4. If the user has photos of their own **fictional** character art: open `media_upload_widget` so they pick the file in Higgsfield's window. Chat attachments cannot reach Higgsfield. For web images, use `media_import_url`.
5. For Elements or Soul ID, follow the user's choice in `consistency_method`. Soul ID training needs 5-20 photos and about 10 minutes; offer it, never start it silently.

### 4b. Store every reference in Higgsfield (house rule)
Character, location and prop references live in the learner's Higgsfield account, never only in the chat:
1. Name each reference after its asset and view, e.g. `Rachel – ref front`, `Blue tin – ref 3/4`, `HDB kitchen – plate`.
2. File each one in the project's Higgsfield folder (see section 3) together with the shots.
3. If the live tool list includes a saved-reference tool (Elements, Soul characters — e.g. `show_characters`), save the approved still there under the same name and use that reference in every shot.
4. Write the reference fields back into the asset bible for each asset: Higgsfield name, job or element ID, folder, and the still's result URL. Every shot prompt cites the asset by that name.

## 5. Generate the shots
- Order: hero shots (hook and payoff) first, then the rest in timeline order.
- For each shot:
  - Use the `i2v_prompt` with the chosen still or a previous shot's result as the **start frame** (pass its job ID in `medias`, as the model's `medias[].roles` require).
  - If there is no start frame, use the `t2v_prompt`.
  - Set aspect, `gen_seconds` and resolution from the script.
- Several shots at once: `generate_video_batch` (up to 12 per call). One shot: `generate_video`.
- Poll with `jobs_wait` in groups of at most 12. While `all_terminal` is false, wait `poll_after_seconds` and call again. Use `job_status` for a single job.
- If a job returns `ip_detected`, ask the user to confirm they hold the rights before calling `reveal_generation`.

### Status table (update after every poll, as a Markdown table)

| Shot | Model | Preset/move | Job ID | Status | Credits | Result | Notes |
|---|---|---|---|---|---|---|---|
| S01-SH01 | kling3_0 | Dolly In | … | completed | 16 | [open](url) | — |

Status values: `queued`, `running`, `completed`, `failed`, `needs-rights` (ip_detected), `rejected-by-user`.

## 6. Review loop, failures and retries
- After each group completes, show the results with one `show_generation_by_ids` call. Ask: "Keep, or re-roll with a note?"
- **Retry policy:**
  - Up to 2 automatic retries on `failed`: same prompt first, then simplify (drop the effect, shorten the action).
  - Content-policy failure: rewrite the prompt neutrally and tell the user what changed.
  - Character drift: regenerate from the reference start frame instead of t2v.
  - Garbled text: drop the text from the prompt and plan an editor overlay.
- Track spent credits against the approved budget. At 80%, pause and ask before continuing.

## 7. Downloads: what the learner clicks
- Give one link per shot, named in timeline order: `S01-SH01.mp4`, `S01-SH02.mp4` and so on.
- Tell the learner:
  > Click each link, then right-click the video and choose **Save video as…**, or open it in Higgsfield **Assets** and download it there. Save into your `05-edit` folder with the shot ID as the filename.
- Do not fetch the MP4s yourself. The sandbox usually blocks those domains, and the assets stay in Higgsfield anyway.

## 8. Hand-off files: write both, every time
Write `lahlah-edit.json` and `captions.srt`. The safest way: fill `templates/production.example.json` with real values and run:

```
python3 scripts/build_handoff.py production.json --out .
```

The script validates the schema and timing, then writes both files. Offer both as downloadable files.

**`lahlah-edit.json` must match this shape exactly** (`references/lahlah-edit.schema.json`):

```json
{"schema":"lahlah-edit/1","title":"...","platform":"tiktok | youtube | youtube-shorts | reels | microdrama","aspect":"9:16","fps":24,
 "higgsfield_project":{"name":"...","url":"..."},
 "clips":[{"id":"S01-SH01","scene":1,"shot":1,"src":"https://...mp4","duration":5.0,"trim_in":0,"trim_out":5.0,"transition_in":"cut|crossfade|slide|zoom|wipe|dip","caption":"...","voiceover":"..."}],
 "audio":[{"src":"...","start":0,"volume":0.6,"type":"music|vo|sfx"}],
 "captions":[{"start":0.0,"end":2.5,"text":"..."}]}
```

Field rules:
- `fps` is the frame rate the clips were generated at, never a default. Seedance shots come out at 24 fps; a 30 fps project repeats every fifth frame and the motion judders. Mixed rates: use the main model's rate and say so.
- `platform` is one value from the list.
- `src` is the Higgsfield result URL, never a re-hosted copy.
- `duration` is the generated clip length.
- `trim_in`/`trim_out` select the part used; `trim_out - trim_in` equals the script's timeline duration.
- Clips appear in timeline order.
- `higgsfield_project.url`: the Assets folder URL if the user shares it, else `https://higgsfield.ai/asset/all`.
- `audio` may be empty. Use local file names for music the user supplies.
- `captions` use timeline seconds and must not overlap.
- The **`.srt`** carries the same captions: `HH:MM:SS,mmm --> HH:MM:SS,mmm`, UTF-8, numbered from 1.

Then tell the learner:
- **LahLah Video:** File > Open edit… > pick `lahlah-edit.json`. *Menu wording depends on the build shipped with the course.*
- **CapCut:**
  1. Import the clips in filename order.
  2. **Captions > Add Captions > Import file** → `captions.srt`. Older builds: Text > Auto Captions > Local captions.
  3. Trim each clip to the timings in the JSON.

## 9. Close-out message (always)
1. The final status table.
2. Total credits spent against budget.
3. The Higgsfield folder name and the list of job IDs to **Move to** it, if not filed automatically.
4. Download links in order.
5. The two hand-off files.
6. Next step: "Edit in LahLah Video, then run `platform-publish`."

## Never
- Generate before both approvals and the budget yes.
- Invent tool names, preset ids, model ids or URLs.
- Publish to TikTok (`tiktok_publish`) from this skill. Publishing belongs to `platform-publish`, and needs the user's explicit go.
- Use real people's names, faces or likenesses.
