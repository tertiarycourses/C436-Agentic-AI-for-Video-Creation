---
name: storyboard
description: Builds a shot-by-shot storyboard as one self-contained HTML artifact with a DRAFT banner, then stops for the user's approval. Use after the story brief, before the script.
---

# Storyboard: shot cards for approval

You turn an approved story brief into a **storyboard artifact**: a grid of shot cards the user can scan on a laptop or phone, comment on and approve. Nothing goes to Higgsfield until the storyboard says **APPROVED**.

## Preconditions
- An approved story brief, from the `storytelling` skill or in project knowledge as `01-idea__story-brief.md`.
- No approved brief? Say so and offer to run `storytelling` first. Do not invent the story.

## Build the shot list
1. Break each beat into shots. Rough guide:
   - Micro-drama: 10-14 shots per 60 s.
   - Ads: 6-10 shots per 15-30 s.
   - Most models render 4-15 s per clip, so plan shots of 3-8 s.
2. Fill **every** field for every shot:

| Field | Rule |
|---|---|
| `id` | `S01-SH01` style. Scene number, then shot number. |
| `scene`, `shot` | Integers. |
| `start`, `end`, `duration` | Seconds. `end - start = duration`. Shots run back to back. |
| `size` | ECU, CU, MCU, MS, MWS, WS or EWS. |
| `angle` | Eye level, low, high, overhead, Dutch, POV or OTS. |
| `move` | A Higgsfield Camera Controls name: Static, Dolly In, Crash Zoom In, Arc Left, 360 Orbit, Crane Up, FPV Drone and so on. Use `Static` when nothing moves. |
| `effect` | Optional extra: Focus Change, Low Shutter, Bullet Time, Hyperlapse, a speed ramp. Blank is fine. |
| `action` | What happens, in present tense. One or two sentences. |
| `dialogue` | Spoken lines with the speaker in caps, e.g. `RACHEL (VO): "…"`. |
| `onscreen` | On-screen text, 6 words or fewer, or blank. |
| `audio` | SFX and music cues. |
| `assets` | `@Rachel`, `@BlueTin`, `#HDB-living-room` and so on. Each must exist in the character bible or asset list. |
| `prompt` | The Higgsfield prompt draft. Follow the formula below. |
| `transition_in` | One of cut, crossfade, slide, zoom, wipe or dip. These match `lahlah-edit.json`. |

3. **Run a timing check.** The durations must add up to the target length, ±0.5 s. Show the sum in the artifact header.

### Higgsfield prompt formula (one line per shot)
`[shot size] [angle] of [subject + @asset look], [action], in [location + time of day], [lighting], [mood], [colour grade], camera: [move], [lens], [aspect], no on-screen text`

Text on screen is added in the editor, not generated: AI models garble lettering. The exception is a deliberate prop label, such as the tin's envelopes. Plan an editor overlay for those as a fallback.

## Render the artifact
1. Open `templates/storyboard-template.html`.
2. Replace **only** the JSON inside `<script id="storyboard-data" type="application/json">`. Keep everything else as it is.
3. Set `"status": "DRAFT"` and `"version": 1`, or bump the version on each revision.
4. Publish it as **one self-contained HTML artifact** titled `Storyboard: [TITLE] v[N] (DRAFT)`.
5. No external images, fonts or scripts. The artifact sandbox blocks them.

## Stop and ask: the approval gate
After the artifact, send exactly this, then **stop**:

> **Storyboard v[N] is a DRAFT.** Check the shots, the timing (total [X] s of [TARGET] s) and the camera moves.
> Reply **APPROVE** to lock it, or tell me the changes (e.g. "SH04: make it a Crash Zoom In; cut SH07").
> Tip: the "Copy feedback" button in the artifact collects your notes per shot.

Rules:
- Do not write the script or call any Higgsfield tool in the same turn.
- **Only an explicit approval counts:** "approve", "approved", "lock it", "go ahead", "yes, approved". "Looks good, but…" is a change request.
- On change requests, apply them, bump `version`, keep `status: "DRAFT"`, re-render and ask again. List what changed at the top of `changelog`.
- On approval:
  - Set `"status": "APPROVED"`, `"approved_at"` to an ISO timestamp, and `"approved_by"` to the user's name if known, else "user".
  - Re-render the artifact with the title `(APPROVED)`.
  - Tell the user to save it to project knowledge as `02-storyboard__storyboard-v[N]-approved.html`.

## Quality bar
- Shot 1 lands the hook from the brief within 3 s, and it reads with the sound off.
- No two consecutive shots share size, angle and move. Vary at least one.
- One motivated camera move per shot. Static is a choice, not a default.
- Continuity: wardrobe, props and screen direction match the character bible. Rachel stays frame-left in two-shots.
- The end card holds at least 3 s. For Kopi & Coins it carries the CTA and "For general education only. Not financial advice."
- Captions sit above the bottom 35% on vertical platforms. Note this in `onscreen` if text is long.
