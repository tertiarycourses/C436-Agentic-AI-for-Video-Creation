# Story structures by genre (with timings)

Timings are for the default length shown. Scale them proportionally.

## 1. Micro-drama: standalone episode (60 s)
| Beat | Time | Job |
|---|---|---|
| Cold open | 0-5 s | The crisis, already happening. No set-up. |
| Ask | 5-15 s | The hero asks for help or makes a bad move. |
| Turn | 15-30 s | Someone or something reveals the rule. |
| Choice | 30-45 s | The hero acts on it. Montage is allowed. |
| Payoff | 45-55 s | Same kind of crisis, handled. Mirror shot 1. |
| End card | 55-60 s | CTA + disclaimer. |
Kopi & Coins Ep 1 "The Rainy-Day Tin" follows this exactly.

## 2. Micro-drama: serial episode, ReelShort-style (60-90 s)
| Beat | Time | Job |
|---|---|---|
| Recap sting | 0-3 s | Last episode's cliffhanger frame, 1 line. |
| Escalation | 3-25 s | The problem gets worse or a secret surfaces. |
| Confrontation | 25-60 s | Two characters want opposite things. |
| Cliffhanger | last 5 s | Cut on a reveal, a ringing phone, a door, a number on a screen. No resolution. |
Rules: one location per episode keeps generation cheap. End on a face reacting, not on an object. Name the next episode's question in the caption ("Will Daniel tell Rachel?").

## 3. Marketing ad: problem → agitate → solve (15-30 s)
| Beat | 15 s | 30 s | Job |
|---|---|---|---|
| Problem | 0-3 | 0-4 | The pain, shot close. |
| Agitate | 3-6 | 4-10 | What it costs: time, money, face. |
| Solve | 6-11 | 10-20 | Product in use, hero shot. |
| Proof | n/a | 20-25 | Number, demo or reaction. |
| Offer | 11-15 | 25-30 | One CTA, logo, URL. |

## 4. Explainer / educational (45-90 s)
Question (0-5 s) → common wrong answer (5-15 s) → why it's wrong (15-30 s) → the right answer with one visual model (30-60 s) → rule of thumb on screen (last 5-10 s).

## 5. UGC testimonial (20-40 s)
Mid-sentence hook to camera → "I didn't think it would work" → first try, shot handheld → the result with a specific detail → soft nudge ("link's in my bio").

## 6. Brand story / mini-documentary (60-180 s)
One telling detail (cold open) → origin → the obstacle that nearly ended it → turning point → today, with people → line that states the belief.

## 7. Music video (song length; plan per section)
Pick 3 visual motifs. Verse: motifs introduced, slower cuts (2-4 s). Chorus: motifs combined, faster cuts (0.5-1.5 s) on the beat. Bridge: break the system (colour, angle or location). Final chorus: everything at once.

## 8. Event recap (30-60 s)
Loudest moment first → arrival → three peak moments → faces and reactions → stat or quote → next date.

## 9. F&B / food (15-30 s)
Sizzle macro → hands at work → plating → first bite + reaction → name, address, opening hours.

## 10. Real estate walkthrough (45-90 s)
Best room or view first → exterior and entrance → flow room by room in walking order → signature feature → neighbourhood in 2 shots → agent CTA. Keep camera moves slow (Dolly In, Arc Left/Right).

## 11. Corporate training (60-120 s)
The costly mistake on screen → why people make it → the right move, step by step → one-line rule → 1-question check.

## Hook bank (pick, then adapt)
- Show the worst moment first ("$1,400 vs $312").
- A number that breaks an assumption.
- A face mid-sentence saying something unexpected.
- An object out of place (a cookie tin on a CFO's desk).
- A before/after split in frame one.
- A question on screen the viewer can't answer yet.
