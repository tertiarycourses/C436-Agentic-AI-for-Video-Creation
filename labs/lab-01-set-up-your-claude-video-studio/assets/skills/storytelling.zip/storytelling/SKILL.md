---
name: storytelling
description: Turns a raw video idea into a story brief with logline, audience, 3-second hook, timed beats by genre, character bible and platform limits. Use before any storyboard or script.
---

# Storytelling: from idea to story brief

You turn one messy idea into a **story brief** the storyboard and script skills can build on. The brief answers one question before anything else: why does a stranger stop scrolling in the first 3 seconds and stay to the end?

## When to run
- The user shares an idea, a brief, a product or a lesson and wants a video.
- The user asks for a logline, hook, beats, story arc or character bible.
- Skip it if an approved story brief already sits in project knowledge (`01-idea__story-brief.md`). Reuse that brief.

## Inputs you need (ask once, in one message, only for what is missing)
1. The idea in one or two sentences.
2. Platform and target length. Default: TikTok, 9:16, 60 s.
3. Audience: who they are and what they already believe.
4. One message. If the user gives three, make them pick one.
5. Must-avoid list (legal, brand, compliance).

Pull the rest from project knowledge. For Kopi & Coins, read the studio brief before you write a word: General education only, no product names, the disclaimer, fictional people.

## Step 1: Pick the structure by genre
Read `references/structures.md` and choose one. Never default to "problem, solution, CTA" for everything.

| Genre | Structure | Hook pattern |
|---|---|---|
| Micro-drama | Cold open on the crisis → reversal → cliffhanger, or payoff for a standalone | Show the worst moment first |
| Product / marketing ad | Problem → agitate → solve → proof → offer | The pain, shot close |
| Explainer / educational | Question → wrong answer → right answer → rule of thumb | A surprising number |
| UGC testimonial | "I didn't believe it" → try → result → nudge | A face talking to camera, mid-sentence |
| Brand story / documentary | Origin → obstacle → turning point → today | One telling detail |
| Music video | Verse image system → chorus escalation → bridge break | Strongest visual on the downbeat |
| Event recap | Arrival → peak moments → faces → what's next | The loudest moment first |
| F&B / food | Sizzle → craft → bite → where to find it | Macro of the hero dish |
| Real estate walkthrough | Hero exterior → flow room by room → signature feature → call | The best room, not the door |
| Corporate training | Mistake on screen → why it happens → the right move → recap | A costly mistake in 3 s |

## Step 2: Write the brief
Use exactly these sections. Keep each tight.

```
# Story brief: [TITLE]
Logline (≤ 30 words): [WHO] wants [WHAT] but [OBSTACLE]; [TURN].
Audience: [who, age, where they watch, what they believe now]
One message: [the single thing they remember]
Hook (0-3 s): [what we SEE] + [what we HEAR] + [on-screen text ≤ 6 words]
Structure: [name from Step 1]
Beats (timed, sum = target length):
  1. 0-3 s  Hook: ...
  2. ...
Ending: [payoff | cliffhanger] + CTA line
Tone: [3 adjectives] + one reference ("like a Netflix cold open, but HDB-warm")
Platform limits: [aspect, length, captions, safe zone, disclosure]
Must avoid: [...]
```

Timing rules:
- Beats must add up to the target length, ±1 s.
- A 60 s piece has 5-7 beats. A 15 s ad has 3.
- About 2.5 spoken words per second. A 60 s piece carries about 130-150 words at most; Kopi & Coins aims for about 60 so the pictures breathe.

## Step 3: Character bible (only for stories with people)
For each recurring character, write one block. The video skills paste this text into every image and video prompt, so precise wins over poetic.

```
@[Handle]: [Name], [age], [ethnicity if relevant], [hair], [face detail], [signature clothing + colour], [one prop], [voice: pace, accent, a verbal habit].
Never changes: [3 items that must match in every shot]
```

Kopi & Coins example (from the course labs):
- `@Rachel`: Rachel Tan, 29, Singaporean Chinese, shoulder-length straight black hair, round tortoiseshell glasses, mustard-yellow cardigan over a plain white T-shirt, small silver watch. Warm, slightly anxious. Never changes: glasses, mustard cardigan, frame-left in two-shots.
- `@AhMa`: Ah Ma, 74, short silver permed hair, jade bangle on her left wrist, muted-blue floral blouse, calm knowing smile, dry humour ("Wait ah."). Never changes: bangle, blouse, silver perm.
- `@BlueTin`: round blue butter-cookie tin, small dent on the lid's edge, three envelopes labelled RAINY DAY, ANG PAO, HOLIDAY.

## Step 4: Show it and stop
1. Present the brief as a Markdown artifact titled `Story brief: [TITLE] (DRAFT)`.
2. Ask: "Approve the story, or tell me what to change?"
3. Do not start a storyboard until the user says approve, approved, go or yes.
4. On approval, change the title to `(APPROVED)` and suggest the user save it to project knowledge as `01-idea__story-brief.md`.

## Quality bar (check before you show)
- The hook works with the sound off.
- The single message appears once in VO or text, not three times.
- Every beat changes something: a decision, a reveal or a reversal.
- Micro-drama endings either pay off or cut on an unanswered question. Never on a summary.
- The CTA is one action the viewer can take today.
- Nothing breaks the must-avoid list. For financial-education stories, no product names, no percentages or returns, and the disclaimer sits on the end card.
