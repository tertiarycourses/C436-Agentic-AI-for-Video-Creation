# Platform specs and disclosure rules (checked 8 Nov 2026)

| Platform | Aspect | Frame | Length | File | Safe zone | AI disclosure |
|---|---|---|---|---|---|---|
| TikTok | 9:16 (16:9, 1:1 accepted) | 1080×1920; min 540×960 | Upload ≤ 60 min, record ≤ 10 min; ads 21-34 s recommended | Ads: MP4/MOV ≤ 500 MB | No official pixels. Third-party: ~130 px top, ~370-480 px bottom, ~120-140 px right (awaiting verification) | More options > AI-generated content |
| YouTube | 16:9 | 1920×1080 or 3840×2160 | 15 min until verified | MP4, H.264 High, AAC-LC 48 kHz; 8 Mbps at 1080p30; BT.709 | — | Attributes > AI use = Yes |
| YouTube Shorts | 9:16 or 1:1 | 1080×1920 | ≤ 3 min | as YouTube | No official figure | same |
| Instagram Reels | 9:16 | 1080×1920 (ads guide: 1440×2560) | ≤ 20 min; > 3 min not recommended to new audiences | MP4/MOV, H.264, AAC | 14% top, 35% bottom, 6% sides | Add AI label (awaiting verification) |
| LinkedIn | 1:2.4 to 2.4:1 | ≤ 4096×2304, 10-60 fps | Members 15 min, Pages 10 min | 75 KB-5 GB | Not retrieved | No toggle; C2PA "CR" label |
| Micro-drama apps | 9:16 | 1080×1920 (norm) | 1-2 min per episode | No public spec | Use Reels figures | Per contract |

## Sources
- **TikTok:**
  - https://ads.tiktok.com/help/article/video-ads-specifications
  - https://support.tiktok.com/en/using-tiktok/creating-videos/camera-tools
  - https://support.tiktok.com/en/using-tiktok/creating-videos/ai-generated-content
  - https://ads.tiktok.com/business/en/blog/creative-that-drives-conversions
- **YouTube:**
  - https://support.google.com/youtube/answer/1722171
  - https://support.google.com/youtube/answer/71673
  - https://support.google.com/youtube/answer/72431 (thumbnail: 3840×2160 recommended, min width 640, 2 MB mobile / 50 MB desktop)
  - https://support.google.com/youtube/answer/14328491
  - https://support.google.com/youtube/answer/15424877
- **Instagram:**
  - https://help.instagram.com/2720958398006062/
  - https://www.facebook.com/business/ads-guide/update/video/instagram-reels
  - https://about.fb.com/news/2024/02/labeling-ai-generated-images-on-facebook-instagram-and-threads/
  - https://blog.hootsuite.com/ai-disclosure-policy-for-instagram/
- **LinkedIn:**
  - https://www.linkedin.com/help/linkedin/answer/a7174587
  - https://www.linkedin.com/help/linkedin/answer/a1311816
- **Micro-drama:**
  - https://deadline.com/2026/06/microdrama-ai-reelshort-joey-jia-crazy-maple-studio-asia-1236958231 (1-2 min episodes; ReelShort 70-80 episodes per season; first episodes free)
  - https://www.npr.org/2025/03/19/nx-s1-5330470/micro-drama-soap-opera-app
  - https://techcrunch.com/2026/08/29/hollywood-celebs-are-getting-into-microdrama-apps

## When YouTube says disclosure is required
Realistic content that:
- makes a real person say or do something they didn't,
- alters footage of a real event or place, or
- shows a realistic scene that never happened.

Not required for:
- animation or fantasy,
- beauty filters,
- AI help with the script, captions or thumbnail.

Undisclosed content may be labelled by YouTube or removed.
