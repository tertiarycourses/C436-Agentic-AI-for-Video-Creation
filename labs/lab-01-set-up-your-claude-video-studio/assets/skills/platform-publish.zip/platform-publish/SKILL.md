---
name: platform-publish
description: Finishes an edited video for TikTok, YouTube, Shorts, Reels, LinkedIn or micro-drama apps: export settings, captions, title, hashtags, thumbnail prompt, AI disclosure, posting checklist.
---

# Platform publish: from final cut to posted

You prepare everything the learner needs to post: export settings, copy, a thumbnail prompt and the AI-disclosure steps. Then you walk a checklist. You never post on the user's behalf unless they say "post it now" for a specific account. Even then, confirm once.

## Inputs
- Platform(s): tiktok, youtube, youtube-shorts, reels, linkedin or microdrama.
- The approved script, for title, message and captions, plus `lahlah-edit.json` for the length.
- Brand rules from project knowledge. Kopi & Coins:
  - Disclaimer on screen.
  - No product names or returns.
  - AI disclosure on every upload (studio rule 5).
  - Captions on every spoken line (rule 6).

## 1. Export settings (tell the learner what to set in LahLah Video or CapCut)
Read `references/platform-specs.md`. Default export: **H.264 MP4, AAC 48 kHz, constant frame rate (30 fps unless the project says otherwise), about -14 LUFS integrated, true peak ≤ -1 dBTP.**

| Platform | Frame | Length to aim for | Notes |
|---|---|---|---|
| TikTok | 1080×1920, 9:16 | 21-60 s (ads 21-34 s) | Keep text clear of the right-side buttons and bottom caption area |
| YouTube | 1920×1080, 16:9 | any; 15 min cap until the account is verified | 8 Mbps at 1080p30; thumbnail 16:9 |
| YouTube Shorts | 1080×1920, 9:16 or 1:1 | ≤ 3 min | Vertical or square only |
| Instagram Reels | 1080×1920, 9:16 | ≤ 3 min to reach new audiences | Meta safe zone: 14% top, 35% bottom, 6% sides |
| LinkedIn | 1080×1920, 1920×1080 or 1080×1080 | ≤ 10 min for Pages | 75 KB-5 GB |
| Micro-drama app style | 1080×1920, 9:16 | 60-120 s per episode | No public app spec; cliffhanger ending, recap sting at the top |

## 2. Captions
- Burn in captions for vertical platforms: 2 lines max, above the bottom 35%, high contrast.
- Also upload the `.srt` where the platform accepts it (YouTube, LinkedIn) for accessibility and search.
- Every spoken line is captioned. Check names and numbers by hand.

## 3. Copy package (write all of it, per platform)
- **Title / first line:** lead with the hook, not the brand. YouTube titles ≤ 70 characters, so they don't truncate. TikTok and Reels: the first line of the caption does the title's job.
- **Description:** 2-4 short lines. What happens, why it matters, the CTA. Then the disclaimer where required.
- **Hashtags:** 3-5 specific ones beat 20 generic ones. Mix 1 broad, 2 niche, 1 series tag (`#KopiAndCoins`), 1 location (`#Singapore`). No banned or misleading tags.
- **Pinned comment:** one question that invites replies ("What's in your rainy-day tin?").
- **Series fields** (micro-drama): episode number, "Part X of Y", and the next episode's question.

## 4. Thumbnail / cover prompt
Write one Higgsfield image prompt (the user runs it, or `higgsfield-video` does with approval):
`[size: 1280×720 for YouTube; 1080×1920 cover for Shorts/Reels/TikTok], [the emotional peak frame], [one face with a clear expression], [high contrast], [space on one side for 3-4 words added in the editor], no text in the generated image`
Then give the overlay words (≤ 4) separately.

## 5. AI disclosure: say exactly where to click
Disclose every time on this course, even where the rule wouldn't require it.

- **TikTok:**
  1. **Add post**, then **Next**.
  2. **More options**, then turn on **AI-generated content**.
  3. Required for realistic AI images, audio or video.
  4. If TikTok auto-labels the upload (C2PA), you cannot remove the label. That's fine.
- **YouTube / Shorts:** in YouTube Studio's upload flow, open **Attributes > AI use** and select **Yes**. This is required when realistic content shows events that did not happen.
- **Instagram Reels:** after selecting the video, tap **Next**, then turn on **Add AI label**. Meta requires disclosure for photorealistic AI video. *The toggle wording comes from a third-party guide and is awaiting verification.*
- **LinkedIn:** no creator toggle found. Say "Made with AI (Higgsfield)" in the post text.
- **Micro-drama apps:** apps commission content; follow the commissioning contract.

Never on any platform, label or not: real public figures endorsing something, anyone under 18's likeness, private people without consent, fake news or authority sources.

## 6. Posting checklist (show as a checklist artifact; the user ticks it)
- [ ] File: right frame size, 30 fps constant, H.264 MP4, loudness about -14 LUFS.
- [ ] Hook lands in 3 s with the sound off.
- [ ] Captions on every spoken line, inside the safe zone, spelling checked.
- [ ] End card shows for ≥ 3 s with the CTA (+ disclaimer for Kopi & Coins).
- [ ] No real names, NRIC numbers, phone numbers, bank screens or logos on screen.
- [ ] Music licence recorded.
- [ ] AI disclosure switched on.
- [ ] Title, description, hashtags and pinned comment pasted.
- [ ] Thumbnail/cover set.
- [ ] Final file and links saved to `06-publish`; Higgsfield folder link recorded.

## 7. Optional: post to TikTok from Claude
Only if the user asks:
1. Call `tiktok_accounts` to list connected accounts.
2. Show the exact caption, the music choice and the visibility setting.
3. Ask: "Post this to @[account] now?"
4. Only after "yes", call `tiktok_publish`.

Higgsfield's TikTok tools post to a real profile and cannot be undone from here.

## 8. Micro-drama series pack (when platform = microdrama)
- An episode list with a cliffhanger line per episode.
- The paywall-position assumption, clearly marked "industry practice, not a published rule". Trade press says the first few episodes are free.
- Per-episode recap sting (≤ 3 s), episode card text, and the series poster prompt (9:16).
